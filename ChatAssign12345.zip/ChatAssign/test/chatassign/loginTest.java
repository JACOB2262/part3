   package chatassign;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class loginTest {

    private login loginInstance;

    @BeforeEach
    public void setUp() {
        loginInstance = new login();
    }

    @Test
    public void testCheckUserName() {
        // Valid username: contains '_' and length <= 5
        assertTrue(loginInstance.checkUserName("ky_1"));

        // Invalid: missing '_'
        assertFalse(loginInstance.checkUserName("kyl1"));

        // Invalid: length > 5
        assertFalse(loginInstance.checkUserName("kyle_123"));
    }

    @Test
    public void testCheckPasswordComplexity() {
        // Valid: >= 8 chars, uppercase, digit, special char
        assertTrue(loginInstance.checkPasswordComplexity("Ch3ck15!"));

        // Invalid: missing special character
        assertFalse(loginInstance.checkPasswordComplexity("Ch3ck123"));

        // Invalid: missing uppercase letter
        assertFalse(loginInstance.checkPasswordComplexity("ch3ck15!"));

        // Invalid: less than 8 characters
        assertFalse(loginInstance.checkPasswordComplexity("Ch3ck!"));
    }

    @Test
    public void testCheckCellPhoneNumber() {
        // Valid: starts with '+' and international code
        assertTrue(loginInstance.checkCellPhoneNumber("+27838968976"));

        // Invalid: missing '+' international code
        assertFalse(loginInstance.checkCellPhoneNumber("0838968976"));
    }

    @Test
    public void testRegisterUser() {
        // Test successful registration
        String successMessage = loginInstance.registerUser("John", "Doe", "j_1", "P@ssw0rd1", "+27838968976");
        assertEquals("Username successfully captured.\nPassword successfully captured.\nCell number successfully captured.", successMessage);

        // Test invalid username formatting error message
        String failUsername = loginInstance.registerUser("John", "Doe", "john_doe", "P@ssw0rd1", "+27838968976");
        assertTrue(failUsername.contains("Username is not correctly formatted"));

        // Test invalid password formatting error message
        String failPassword = loginInstance.registerUser("John", "Doe", "j_1", "password", "+27838968976");
        assertTrue(failPassword.contains("Password is not correctly formatted"));

        // Test invalid cell number error message
        String failCell = loginInstance.registerUser("John", "Doe", "j_1", "P@ssw0rd1", "0838968976");
        assertTrue(failCell.contains("Cell number is incorrectly formatted"));
    }

    @Test
    public void testLoginUser() {
        // Register user first
        loginInstance.registerUser("John", "Doe", "j_1", "P@ssw0rd1", "+27838968976");

        // Valid credentials
        assertTrue(loginInstance.loginUser("j_1", "P@ssw0rd1"));

        // Invalid password
        assertFalse(loginInstance.loginUser("j_1", "WrongPassword1!"));

        // Invalid username
        assertFalse(loginInstance.loginUser("wrong_user", "P@ssw0rd1"));
    }

    @Test
    public void testReturnLoginStatus() {
        loginInstance.registerUser("John", "Doe", "j_1", "P@ssw0rd1", "+27838968976");

        // Status on successful login
        String successStatus = loginInstance.returnLoginStatus(true);
        assertEquals("Welcome John, Doe it is great to see you again.", successStatus);

        // Status on failed login
        String failStatus = loginInstance.returnLoginStatus(false);
        assertEquals("Username or password incorrect, please try again.", failStatus);
    }
}