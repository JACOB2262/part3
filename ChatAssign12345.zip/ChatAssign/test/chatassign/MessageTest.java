package chatassign;

import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MessageTest {

    private Message messageInstance;

    @BeforeEach
    public void setUp() {
        messageInstance = new Message();
        messageInstance.getSentMessages().clear();
        messageInstance.getDisregardedMessages().clear();
        messageInstance.getStoredMessages().clear();
        messageInstance.getMessageHashes().clear();
        messageInstance.getMessageIDs().clear();

        // Populate test data from Part 3 (Messages 1-5)
        messageInstance.recordMessage("1000000001", 1, "dev_1", "+27834557896",
                "Did you get the cake?",
                messageInstance.createMessageHash("1000000001", 1, "Did you get the cake?"), "Sent");

        messageInstance.recordMessage("1000000002", 2, "dev_1", "+27838884567",
                "Where are you? You are late! I have asked you to be on time.",
                messageInstance.createMessageHash("1000000002", 2, "Where are you? You are late! I have asked you to be on time."), "Stored");

        messageInstance.recordMessage("1000000003", 3, "dev_1", "+27834484567",
                "Yohoooo, I am at your gate.",
                messageInstance.createMessageHash("1000000003", 3, "Yohoooo, I am at your gate."), "Disregard");

        messageInstance.recordMessage("0838884567", 4, "0838884567", "+27834557896",
                "It is dinner time !",
                messageInstance.createMessageHash("0838884567", 4, "It is dinner time !"), "Sent");

        messageInstance.recordMessage("1000000005", 5, "dev_1", "+27838884567",
                "Ok, I am leaving without you.",
                messageInstance.createMessageHash("1000000005", 5, "Ok, I am leaving without you."), "Stored");
    }

    @Test
    public void testSentMessagesArrayPopulated() {
        List<Message.MessageRecord> sent = messageInstance.getSentMessages();
        assertEquals("Did you get the cake?", sent.get(0).messageText);
        assertEquals("It is dinner time !", sent.get(1).messageText);
    }

    @Test
    public void testLongestMessage() {
        assertEquals("Where are you? You are late! I have asked you to be on time.",
                messageInstance.getLongestStoredMessage());
    }

    @Test
    public void testSearchByMessageID() {
        assertEquals("It is dinner time !", messageInstance.searchMessageByID("0838884567"));
    }

    @Test
    public void testSearchByRecipient() {
        List<String> matches = messageInstance.searchMessagesByRecipient("+27838884567");
        assertEquals("Where are you? You are late! I have asked you to be on time.", matches.get(0));
        assertEquals("Ok, I am leaving without you.", matches.get(1));
    }

    @Test
    public void testDeleteByMessageHash() {
        String msg2Hash = messageInstance.createMessageHash(
                "1000000002", 2, "Where are you? You are late! I have asked you to be on time.");
        String result = messageInstance.deleteMessageByHash(msg2Hash);
        assertEquals("Message \"Where are you? You are late! I have asked you to be on time.\" successfully deleted.", result);
    }

    @Test
    public void testDisplayReport() {
        String report = messageInstance.displaySentMessagesReport();
        assertTrue(report.contains("Did you get the cake?"));
        assertTrue(report.contains("It is dinner time !"));
    }
}