package chatassign;

import java.util.List;
import java.util.Scanner;

public class ChatAssign {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        login userLogin = new login();

        System.out.println("--- REGISTRATION PAGE ---");

        System.out.print("Enter first name: ");
        String firstName = input.nextLine();

        System.out.print("Enter last name: ");
        String lastName = input.nextLine();

        String username, password, cellNumber;

        // Loop until valid registration inputs are provided
        while (true) {
            System.out.print("Enter username: ");
            username = input.nextLine();

            System.out.print("Enter password: ");
            password = input.nextLine();

            System.out.print("Enter South African cell phone number (e.g., +27838968976): ");
            cellNumber = input.nextLine();

            String registrationResult = userLogin.registerUser(firstName, lastName, username, password, cellNumber);
            System.out.println("\n" + registrationResult + "\n");

            if (registrationResult.contains("successfully captured")) {
                break;
            }
        }

        System.out.println("--- LOGIN PAGE ---");

        boolean isLoggedIn = false;
        while (true) {
            System.out.print("Enter your username: ");
            String enteredUsername = input.nextLine();

            System.out.print("Enter your password: ");
            String enteredPassword = input.nextLine();

            isLoggedIn = userLogin.loginUser(enteredUsername, enteredPassword);
            System.out.println(userLogin.returnLoginStatus(isLoggedIn));

            if (isLoggedIn) {
                break;
            }
        }

        // ==========================================
        // PART 2 & PART 3: QUICKCHAT MENU
        // ==========================================
        if (isLoggedIn) {
            System.out.println("\nWelcome to QuickChat.");
            Message messageHandler = new Message();
            messageHandler.loadStoredMessagesFromJson();

            boolean running = true;
            while (running) {
                System.out.println("\nPlease choose an option:");
                System.out.println("1) Send Messages");
                System.out.println("2) Show recently sent messages");
                System.out.println("3) Quit");
                System.out.println("4) Stored Messages");
                System.out.print("Enter choice (1-4): ");

                String menuChoice = input.nextLine();

                switch (menuChoice) {
                    case "1":
                        System.out.print("How many messages would you like to enter? ");
                        int totalMessagesToEnter = 0;
                        try {
                            totalMessagesToEnter = Integer.parseInt(input.nextLine());
                        } catch (NumberFormatException e) {
                            System.out.println("Invalid input. Please enter a valid number.");
                            break;
                        }

                        for (int i = 0; i < totalMessagesToEnter; i++) {
                            System.out.println("\n--- Message " + (i + 1) + " of " + totalMessagesToEnter + " ---");

                            System.out.print("Enter recipient cell number (e.g., +27718693002): ");
                            String recipientCell = input.nextLine();
                            String cellCheckResult = messageHandler.checkRecipientCell(recipientCell);
                            System.out.println(cellCheckResult);

                            if (!cellCheckResult.contains("successfully captured")) {
                                System.out.println("Please correct the number and try again.");
                                i--;
                                continue;
                            }

                            System.out.print("Enter your message (max 250 characters): ");
                            String messageText = input.nextLine();

                            if (messageText.length() > 250) {
                                int excess = messageText.length() - 250;
                                System.out.println("Message exceeds 250 characters by " + excess + "; please reduce the size.");
                                i--;
                                continue;
                            } else {
                                System.out.println("Message ready to send.");
                            }

                            String messageID = messageHandler.generateMessageID();
                            String messageHash = messageHandler.createMessageHash(messageID, i, messageText);

                            System.out.println("\nMessage ID generated: " + messageID);
                            System.out.println("Message Hash: " + messageHash);

                            System.out.println("\nChoose an action:");
                            System.out.println("1) Send Message");
                            System.out.println("2) Store Message to send later");
                            System.out.println("0) Disregard Message");
                            System.out.print("Enter action choice: ");

                            int actionChoice = 0;
                            try {
                                actionChoice = Integer.parseInt(input.nextLine());
                            } catch (NumberFormatException e) {
                                actionChoice = 0;
                            }

                            String actionResult = messageHandler.SentMessage(actionChoice);
                            System.out.println(actionResult);

                            if (actionChoice == 1) {
                                messageHandler.recordMessage(messageID, i, username, recipientCell, messageText, messageHash, "Sent");
                                System.out.println("\n[SENT MESSAGE SUMMARY]");
                                System.out.println("Message ID: " + messageID);
                                System.out.println("Message Hash: " + messageHash);
                                System.out.println("Recipient: " + recipientCell);
                                System.out.println("Message: " + messageText);
                            } else if (actionChoice == 2) {
                                messageHandler.recordMessage(messageID, i, username, recipientCell, messageText, messageHash, "Stored");
                            } else {
                                messageHandler.recordMessage(messageID, i, username, recipientCell, messageText, messageHash, "Disregard");
                            }
                        }

                        System.out.println("\nTotal messages sent: " + messageHandler.returnTotalMessagess());
                        break;

                    case "2":
                        System.out.println(messageHandler.displaySentMessagesReport());
                        break;

                    case "3":
                        System.out.println("Exiting QuickChat. Goodbye!");
                        running = false;
                        break;

                    case "4":
                        messageHandler.loadStoredMessagesFromJson();
                        System.out.println("\n--- STORED MESSAGES MENU ---");
                        System.out.println("a) Display sender and recipient of all stored messages");
                        System.out.println("b) Display the longest stored message");
                        System.out.println("c) Search for a message ID");
                        System.out.println("d) Search messages for a particular recipient");
                        System.out.println("e) Delete a message using message hash");
                        System.out.println("f) Display full report of all stored messages");
                        System.out.print("Choose a sub-option (a-f): ");
                        String subChoice = input.nextLine().trim().toLowerCase();

                        switch (subChoice) {
                            case "a":
                                System.out.println(messageHandler.displaySendersAndRecipientsOfStored());
                                break;
                            case "b":
                                System.out.println("Longest stored message: " + messageHandler.getLongestStoredMessage());
                                break;
                            case "c":
                                System.out.print("Enter Message ID to search: ");
                                String searchId = input.nextLine();
                                System.out.println(messageHandler.searchMessageByID(searchId));
                                break;
                            case "d":
                                System.out.print("Enter Recipient number to search: ");
                                String searchRecip = input.nextLine();
                                List<String> found = messageHandler.searchMessagesByRecipient(searchRecip);
                                if (found.isEmpty()) {
                                    System.out.println("No messages found for recipient.");
                                } else {
                                    for (String m : found) {
                                        System.out.println(m);
                                    }
                                }
                                break;
                            case "e":
                                System.out.print("Enter Message Hash to delete: ");
                                String delHash = input.nextLine();
                                System.out.println(messageHandler.deleteMessageByHash(delHash));
                                break;
                            case "f":
                                System.out.println(messageHandler.displayStoredMessagesReport());
                                break;
                            default:
                                System.out.println("Invalid sub-option.");
                        }
                        break;

                    default:
                        System.out.println("Invalid option. Please choose 1, 2, 3, or 4.");
                }
            }
        }

        input.close();
    }
}