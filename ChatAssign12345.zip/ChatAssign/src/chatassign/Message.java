package chatassign;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Message {

    public static class MessageRecord {
        public String messageID;
        public int messageNumber;
        public String sender;
        public String recipient;
        public String messageText;
        public String messageHash;
        public String flag;

        public MessageRecord(String messageID, int messageNumber, String sender, String recipient,
                             String messageText, String messageHash, String flag) {
            this.messageID = messageID;
            this.messageNumber = messageNumber;
            this.sender = sender;
            this.recipient = recipient;
            this.messageText = messageText;
            this.messageHash = messageHash;
            this.flag = flag;
        }
    }

    // Populated dynamically at runtime (no hard-coding)
    private static final List<MessageRecord> sentMessages = new ArrayList<>();
    private static final List<MessageRecord> disregardedMessages = new ArrayList<>();
    private static final List<MessageRecord> storedMessages = new ArrayList<>();
    private static final List<String> messageHashes = new ArrayList<>();
    private static final List<String> messageIDs = new ArrayList<>();
    private static int totalMessagesCount = 0;

    public boolean checkMessageID(String messageID) {
        return messageID != null && messageID.length() <= 10;
    }

    public String checkRecipientCell(String cellNumber) {
        if (cellNumber != null && cellNumber.matches("^\\+\\d{1,3}\\d{1,10}$")) {
            return "Cell phone number successfully captured.";
        } else {
            return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
        }
    }

    public String createMessageHash(String messageID, int messageNumber, String messageText) {
        String idPrefix = (messageID != null && messageID.length() >= 2) ? messageID.substring(0, 2) : "00";

        String firstWord = "";
        String lastWord = "";

        if (messageText != null && !messageText.trim().isEmpty()) {
            String[] words = messageText.trim().split("\\s+");
            firstWord = words[0].replaceAll("[^a-zA-Z0-9]", "");
            lastWord = words[words.length - 1].replaceAll("[^a-zA-Z0-9]", "");
        }

        String hash = idPrefix + ":" + messageNumber + ":" + firstWord + lastWord;
        return hash.toUpperCase();
    }

    public String SentMessage(int choice) {
        switch (choice) {
            case 1:
                totalMessagesCount++;
                return "Message successfully sent.";
            case 2:
                return "Message successfully stored.";
            case 0:
            default:
                return "Press 0 to delete the message";
        }
    }

    public String printMessages() {
        if (sentMessages.isEmpty()) {
            return "No messages sent yet.";
        }
        StringBuilder sb = new StringBuilder();
        for (MessageRecord m : sentMessages) {
            sb.append("ID: ").append(m.messageID)
              .append(" | Hash: ").append(m.messageHash)
              .append(" | Recipient: ").append(m.recipient)
              .append(" | Message: ").append(m.messageText).append("\n");
        }
        return sb.toString().trim();
    }

    public int returnTotalMessagess() {
        return totalMessagesCount;
    }

    public String generateMessageID() {
        Random rand = new Random();
        long id = 1000000000L + (long) (rand.nextDouble() * 9000000000L);
        return String.valueOf(id);
    }

    public void recordMessage(String messageID, int messageNumber, String sender, String recipient,
                              String messageText, String hash, String flag) {
        MessageRecord record = new MessageRecord(messageID, messageNumber, sender, recipient, messageText, hash, flag);
        messageIDs.add(messageID);
        messageHashes.add(hash);

        if ("Sent".equalsIgnoreCase(flag)) {
            sentMessages.add(record);
        } else if ("Disregard".equalsIgnoreCase(flag)) {
            disregardedMessages.add(record);
        } else if ("Stored".equalsIgnoreCase(flag)) {
            storedMessages.add(record);
            storeMessageToJsonFile(record);
        }
    }

    public void storeMessageToJsonFile(MessageRecord record) {
        String jsonEntry = String.format(
            "{\"messageID\":\"%s\",\"sender\":\"%s\",\"recipient\":\"%s\",\"messageHash\":\"%s\",\"message\":\"%s\"}%n",
            escapeJson(record.messageID),
            escapeJson(record.sender),
            escapeJson(record.recipient),
            escapeJson(record.messageHash),
            escapeJson(record.messageText)
        );
        try (FileWriter file = new FileWriter("stored_messages.json", true)) {
            file.write(jsonEntry);
        } catch (IOException e) {
            System.out.println("Error saving message to JSON: " + e.getMessage());
        }
    }

    public void loadStoredMessagesFromJson() {
        File file = new File("stored_messages.json");
        if (!file.exists()) {
            return;
        }
        storedMessages.clear();
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.startsWith("{") && line.endsWith("}")) {
                    String id = extractJsonValue(line, "messageID");
                    String sender = extractJsonValue(line, "sender");
                    String recipient = extractJsonValue(line, "recipient");
                    String hash = extractJsonValue(line, "messageHash");
                    String msg = extractJsonValue(line, "message");
                    storedMessages.add(new MessageRecord(id, storedMessages.size() + 1, sender, recipient, msg, hash, "Stored"));
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading JSON file: " + e.getMessage());
        }
    }

    public String getLongestStoredMessage() {
        String longest = "";
        for (MessageRecord m : storedMessages) {
            if (m.messageText != null && m.messageText.length() > longest.length()) {
                longest = m.messageText;
            }
        }
        return longest;
    }

    public String searchMessageByID(String targetID) {
        for (MessageRecord m : sentMessages) {
            if (targetID.equals(m.messageID)) {
                return m.messageText;
            }
        }
        for (MessageRecord m : storedMessages) {
            if (targetID.equals(m.messageID)) {
                return m.messageText;
            }
        }
        return "Message ID not found.";
    }

    public List<String> searchMessagesByRecipient(String targetRecipient) {
        List<String> matches = new ArrayList<>();
        for (MessageRecord m : sentMessages) {
            if (targetRecipient.equals(m.recipient)) {
                matches.add(m.messageText);
            }
        }
        for (MessageRecord m : storedMessages) {
            if (targetRecipient.equals(m.recipient)) {
                matches.add(m.messageText);
            }
        }
        return matches;
    }

    public String deleteMessageByHash(String targetHash) {
        for (int i = 0; i < storedMessages.size(); i++) {
            MessageRecord m = storedMessages.get(i);
            if (targetHash.equalsIgnoreCase(m.messageHash)) {
                String removedText = m.messageText;
                storedMessages.remove(i);
                return "Message \"" + removedText + "\" successfully deleted.";
            }
        }
        for (int i = 0; i < sentMessages.size(); i++) {
            MessageRecord m = sentMessages.get(i);
            if (targetHash.equalsIgnoreCase(m.messageHash)) {
                String removedText = m.messageText;
                sentMessages.remove(i);
                return "Message \"" + removedText + "\" successfully deleted.";
            }
        }
        return "Message hash not found.";
    }

    public String displaySendersAndRecipientsOfStored() {
        if (storedMessages.isEmpty()) {
            return "No stored messages available.";
        }
        StringBuilder sb = new StringBuilder();
        for (MessageRecord m : storedMessages) {
            sb.append("Sender: ").append(m.sender)
              .append(" | Recipient: ").append(m.recipient).append("\n");
        }
        return sb.toString().trim();
    }

    public String displayStoredMessagesReport() {
        if (storedMessages.isEmpty()) {
            return "No stored messages in report.";
        }
        StringBuilder sb = new StringBuilder("--- STORED MESSAGES REPORT ---\n");
        for (MessageRecord m : storedMessages) {
            sb.append("Message ID: ").append(m.messageID)
              .append(" | Sender: ").append(m.sender)
              .append(" | Recipient: ").append(m.recipient)
              .append(" | Message Hash: ").append(m.messageHash)
              .append(" | Message: ").append(m.messageText).append("\n");
        }
        return sb.toString().trim();
    }

    public String displaySentMessagesReport() {
        if (sentMessages.isEmpty()) {
            return "No sent messages in report.";
        }
        StringBuilder sb = new StringBuilder("--- SENT MESSAGES REPORT ---\n");
        for (MessageRecord m : sentMessages) {
            sb.append("Message Hash: ").append(m.messageHash)
              .append(" | Recipient: ").append(m.recipient)
              .append(" | Message: ").append(m.messageText).append("\n");
        }
        return sb.toString().trim();
    }

    public List<MessageRecord> getSentMessages() { return sentMessages; }
    public List<MessageRecord> getDisregardedMessages() { return disregardedMessages; }
    public List<MessageRecord> getStoredMessages() { return storedMessages; }
    public List<String> getMessageHashes() { return messageHashes; }
    public List<String> getMessageIDs() { return messageIDs; }

    private String escapeJson(String value) {
        if (value == null) return "";
        return value.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private String extractJsonValue(String json, String key) {
        String search = "\"" + key + "\":\"";
        int start = json.indexOf(search);
        if (start == -1) return "";
        start += search.length();
        int end = json.indexOf("\"", start);
        if (end == -1) return "";
        return json.substring(start, end).replace("\\\"", "\"").replace("\\\\", "\\");
    }
}